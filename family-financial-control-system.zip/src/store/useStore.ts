import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import type {
  User, Income, Expense, CreditCard, FinancialGoal,
  Category, InstallmentGroup, AppSettings
} from '../types';

const DEFAULT_CATEGORIES: Category[] = [
  // Income
  { id: 'cat-sal', name: 'Salário', type: 'income', icon: '💼', color: '#10b981' },
  { id: 'cat-free', name: 'Freelance', type: 'income', icon: '💻', color: '#6366f1' },
  { id: 'cat-venda', name: 'Venda', type: 'income', icon: '🛒', color: '#f59e0b' },
  { id: 'cat-invest', name: 'Investimentos', type: 'income', icon: '📈', color: '#3b82f6' },
  { id: 'cat-outros-in', name: 'Outros', type: 'income', icon: '💰', color: '#8b5cf6' },
  // Expense
  { id: 'cat-alim', name: 'Alimentação', type: 'expense', icon: '🍔', color: '#ef4444' },
  { id: 'cat-farm', name: 'Farmácia', type: 'expense', icon: '💊', color: '#ec4899' },
  { id: 'cat-comb', name: 'Combustível', type: 'expense', icon: '⛽', color: '#f97316' },
  { id: 'cat-ener', name: 'Energia', type: 'expense', icon: '⚡', color: '#eab308' },
  { id: 'cat-agua', name: 'Água', type: 'expense', icon: '💧', color: '#06b6d4' },
  { id: 'cat-inter', name: 'Internet', type: 'expense', icon: '🌐', color: '#8b5cf6' },
  { id: 'cat-alug', name: 'Aluguel', type: 'expense', icon: '🏠', color: '#6366f1' },
  { id: 'cat-esc', name: 'Escola', type: 'expense', icon: '📚', color: '#3b82f6' },
  { id: 'cat-saude', name: 'Saúde', type: 'expense', icon: '🏥', color: '#10b981' },
  { id: 'cat-lazer', name: 'Lazer', type: 'expense', icon: '🎮', color: '#f59e0b' },
  { id: 'cat-cart', name: 'Cartão de Crédito', type: 'expense', icon: '💳', color: '#64748b' },
  { id: 'cat-outros-ex', name: 'Outros', type: 'expense', icon: '📦', color: '#94a3b8' },
];

const DEFAULT_USERS: User[] = [
  { id: 'user-husband', name: 'Marido', role: 'husband', password: '1234', avatar: '👨', color: '#3b82f6' },
  { id: 'user-wife', name: 'Esposa', role: 'wife', password: '1234', avatar: '👩', color: '#ec4899' },
];

function loadFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // ignore
  }
}

interface StoreState {
  // Auth
  currentUser: User | null;
  users: User[];
  login: (role: 'husband' | 'wife', password: string) => boolean;
  logout: () => void;
  updateUser: (id: string, data: Partial<User>) => void;

  // Data
  categories: Category[];
  incomes: Income[];
  expenses: Expense[];
  cards: CreditCard[];
  goals: FinancialGoal[];
  installmentGroups: InstallmentGroup[];

  // Settings
  settings: AppSettings;
  toggleDarkMode: () => void;

  // Income actions
  addIncome: (income: Omit<Income, 'id' | 'createdAt'>) => void;
  updateIncome: (id: string, income: Partial<Income>) => void;
  deleteIncome: (id: string) => void;

  // Expense actions
  addExpense: (expense: Omit<Expense, 'id' | 'createdAt'>) => void;
  addInstallments: (group: Omit<InstallmentGroup, 'id' | 'createdAt'>, startDate: string) => void;
  updateExpense: (id: string, expense: Partial<Expense>) => void;
  deleteExpense: (id: string) => void;
  toggleExpenseStatus: (id: string) => void;

  // Card actions
  addCard: (card: Omit<CreditCard, 'id' | 'createdAt'>) => void;
  updateCard: (id: string, card: Partial<CreditCard>) => void;
  deleteCard: (id: string) => void;

  // Goal actions
  addGoal: (goal: Omit<FinancialGoal, 'id' | 'createdAt'>) => void;
  updateGoal: (id: string, goal: Partial<FinancialGoal>) => void;
  deleteGoal: (id: string) => void;
  contributeToGoal: (id: string, amount: number) => void;
}

// Generate some demo data
const today = new Date();
const fmt = (d: Date) => d.toISOString().split('T')[0];
const addDays = (d: Date, n: number) => { const r = new Date(d); r.setDate(r.getDate() + n); return r; };
const addMonths = (d: Date, n: number) => { const r = new Date(d); r.setMonth(r.getMonth() + n); return r; };

const DEMO_INCOMES: Income[] = [
  { id: uuidv4(), date: fmt(new Date(today.getFullYear(), today.getMonth(), 5)), value: 5000, description: 'Salário Março', categoryId: 'cat-sal', userId: 'user-husband', notes: '', createdAt: new Date().toISOString() },
  { id: uuidv4(), date: fmt(new Date(today.getFullYear(), today.getMonth(), 5)), value: 3500, description: 'Salário Março', categoryId: 'cat-sal', userId: 'user-wife', notes: '', createdAt: new Date().toISOString() },
  { id: uuidv4(), date: fmt(new Date(today.getFullYear(), today.getMonth(), 10)), value: 800, description: 'Freelance Website', categoryId: 'cat-free', userId: 'user-husband', notes: '', createdAt: new Date().toISOString() },
  { id: uuidv4(), date: fmt(new Date(today.getFullYear(), today.getMonth(), 15)), value: 200, description: 'Dividendos', categoryId: 'cat-invest', userId: 'user-husband', notes: '', createdAt: new Date().toISOString() },
];

const DEMO_EXPENSES: Expense[] = [
  { id: uuidv4(), purchaseDate: fmt(new Date(today.getFullYear(), today.getMonth(), 1)), dueDate: fmt(new Date(today.getFullYear(), today.getMonth(), 10)), value: 1200, description: 'Aluguel', categoryId: 'cat-alug', paymentMethod: 'transfer', userId: 'user-husband', status: 'paid', createdAt: new Date().toISOString() },
  { id: uuidv4(), purchaseDate: fmt(new Date(today.getFullYear(), today.getMonth(), 2)), dueDate: fmt(new Date(today.getFullYear(), today.getMonth(), 15)), value: 350, description: 'Supermercado', categoryId: 'cat-alim', paymentMethod: 'debit', userId: 'user-wife', status: 'paid', createdAt: new Date().toISOString() },
  { id: uuidv4(), purchaseDate: fmt(today), dueDate: fmt(addDays(today, 5)), value: 180, description: 'Conta de Energia', categoryId: 'cat-ener', paymentMethod: 'pix', userId: 'user-husband', status: 'pending', createdAt: new Date().toISOString() },
  { id: uuidv4(), purchaseDate: fmt(today), dueDate: fmt(addDays(today, -2)), value: 95, description: 'Conta de Água', categoryId: 'cat-agua', paymentMethod: 'pix', userId: 'user-wife', status: 'pending', createdAt: new Date().toISOString() },
  { id: uuidv4(), purchaseDate: fmt(today), dueDate: fmt(addDays(today, 10)), value: 120, description: 'Internet', categoryId: 'cat-inter', paymentMethod: 'debit', userId: 'user-husband', status: 'pending', createdAt: new Date().toISOString() },
  { id: uuidv4(), purchaseDate: fmt(new Date(today.getFullYear(), today.getMonth(), 3)), dueDate: fmt(new Date(today.getFullYear(), today.getMonth(), 20)), value: 250, description: 'Farmácia', categoryId: 'cat-farm', paymentMethod: 'credit', userId: 'user-wife', status: 'pending', createdAt: new Date().toISOString() },
  { id: uuidv4(), purchaseDate: fmt(new Date(today.getFullYear(), today.getMonth(), 8)), dueDate: fmt(new Date(today.getFullYear(), today.getMonth(), 8)), value: 200, description: 'Combustível', categoryId: 'cat-comb', paymentMethod: 'money', userId: 'user-husband', status: 'paid', createdAt: new Date().toISOString() },
  { id: uuidv4(), purchaseDate: fmt(new Date(today.getFullYear(), today.getMonth(), 12)), dueDate: fmt(new Date(today.getFullYear(), today.getMonth(), 25)), value: 500, description: 'Escola', categoryId: 'cat-esc', paymentMethod: 'transfer', userId: 'user-wife', status: 'pending', createdAt: new Date().toISOString() },
  { id: uuidv4(), purchaseDate: fmt(today), dueDate: fmt(addDays(today, -5)), value: 300, description: 'Plano de Saúde', categoryId: 'cat-saude', paymentMethod: 'debit', userId: 'user-husband', status: 'pending', createdAt: new Date().toISOString() },
  { id: uuidv4(), purchaseDate: fmt(new Date(today.getFullYear(), today.getMonth(), 14)), dueDate: fmt(new Date(today.getFullYear(), today.getMonth(), 14)), value: 150, description: 'Cinema + Jantar', categoryId: 'cat-lazer', paymentMethod: 'credit', userId: 'user-wife', status: 'paid', createdAt: new Date().toISOString() },
];

const DEMO_CARDS: CreditCard[] = [
  { id: 'card-1', name: 'Nubank', limit: 5000, closingDay: 15, dueDay: 22, color: '#8b5cf6', userId: 'user-husband', createdAt: new Date().toISOString() },
  { id: 'card-2', name: 'Itaú', limit: 8000, closingDay: 10, dueDay: 17, color: '#f97316', userId: 'user-wife', createdAt: new Date().toISOString() },
];

const DEMO_GOALS: FinancialGoal[] = [
  { id: 'goal-1', name: 'Comprar Carro', targetValue: 30000, currentValue: 12000, targetDate: fmt(addMonths(today, 18)), description: 'Novo carro da família', icon: '🚗', color: '#3b82f6', userId: 'user-husband', createdAt: new Date().toISOString() },
  { id: 'goal-2', name: 'Viagem de Férias', targetValue: 8000, currentValue: 3200, targetDate: fmt(addMonths(today, 6)), description: 'Viagem para a praia', icon: '✈️', color: '#10b981', userId: 'user-wife', createdAt: new Date().toISOString() },
  { id: 'goal-3', name: 'Reforma da Casa', targetValue: 15000, currentValue: 5500, targetDate: fmt(addMonths(today, 12)), description: 'Reforma da sala e cozinha', icon: '🏠', color: '#f59e0b', userId: 'user-husband', createdAt: new Date().toISOString() },
];

export const useStore = create<StoreState>((set, get) => ({
  currentUser: null,
  users: loadFromStorage('users', DEFAULT_USERS),
  categories: DEFAULT_CATEGORIES,
  incomes: loadFromStorage('incomes', DEMO_INCOMES),
  expenses: loadFromStorage('expenses', DEMO_EXPENSES),
  cards: loadFromStorage('cards', DEMO_CARDS),
  goals: loadFromStorage('goals', DEMO_GOALS),
  installmentGroups: loadFromStorage('installmentGroups', []),
  settings: loadFromStorage('settings', { darkMode: false, currency: 'BRL', language: 'pt-BR' }),

  login: (role, password) => {
    const { users } = get();
    const user = users.find(u => u.role === role && u.password === password);
    if (user) {
      set({ currentUser: user });
      return true;
    }
    return false;
  },

  logout: () => set({ currentUser: null }),

  updateUser: (id, data) => {
    set(state => {
      const users = state.users.map(u => u.id === id ? { ...u, ...data } : u);
      saveToStorage('users', users);
      return { users, currentUser: state.currentUser?.id === id ? { ...state.currentUser, ...data } : state.currentUser };
    });
  },

  toggleDarkMode: () => {
    set(state => {
      const settings = { ...state.settings, darkMode: !state.settings.darkMode };
      saveToStorage('settings', settings);
      return { settings };
    });
  },

  addIncome: (income) => {
    const newIncome: Income = { ...income, id: uuidv4(), createdAt: new Date().toISOString() };
    set(state => {
      const incomes = [...state.incomes, newIncome];
      saveToStorage('incomes', incomes);
      return { incomes };
    });
  },

  updateIncome: (id, income) => {
    set(state => {
      const incomes = state.incomes.map(i => i.id === id ? { ...i, ...income } : i);
      saveToStorage('incomes', incomes);
      return { incomes };
    });
  },

  deleteIncome: (id) => {
    set(state => {
      const incomes = state.incomes.filter(i => i.id !== id);
      saveToStorage('incomes', incomes);
      return { incomes };
    });
  },

  addExpense: (expense) => {
    const newExpense: Expense = { ...expense, id: uuidv4(), createdAt: new Date().toISOString() };
    set(state => {
      const expenses = [...state.expenses, newExpense];
      saveToStorage('expenses', expenses);
      return { expenses };
    });
  },

  addInstallments: (group, startDate) => {
    const groupId = uuidv4();
    const fullGroup: InstallmentGroup = { ...group, id: groupId, createdAt: new Date().toISOString() };
    const newExpenses: Expense[] = [];

    for (let i = 0; i < group.totalInstallments; i++) {
      const dueDate = new Date(startDate);
      dueDate.setMonth(dueDate.getMonth() + i);
      newExpenses.push({
        id: uuidv4(),
        purchaseDate: startDate,
        dueDate: fmt(dueDate),
        value: group.installmentValue,
        description: `${group.description} (${i + 1}/${group.totalInstallments})`,
        categoryId: group.categoryId,
        paymentMethod: group.paymentMethod,
        userId: group.userId,
        status: 'pending',
        installmentGroupId: groupId,
        installmentNumber: i + 1,
        totalInstallments: group.totalInstallments,
        cardId: group.cardId,
        createdAt: new Date().toISOString(),
      });
    }

    set(state => {
      const expenses = [...state.expenses, ...newExpenses];
      const installmentGroups = [...state.installmentGroups, fullGroup];
      saveToStorage('expenses', expenses);
      saveToStorage('installmentGroups', installmentGroups);
      return { expenses, installmentGroups };
    });
  },

  updateExpense: (id, expense) => {
    set(state => {
      const expenses = state.expenses.map(e => e.id === id ? { ...e, ...expense } : e);
      saveToStorage('expenses', expenses);
      return { expenses };
    });
  },

  deleteExpense: (id) => {
    set(state => {
      const expenses = state.expenses.filter(e => e.id !== id);
      saveToStorage('expenses', expenses);
      return { expenses };
    });
  },

  toggleExpenseStatus: (id) => {
    set(state => {
      const expenses = state.expenses.map(e =>
        e.id === id ? { ...e, status: e.status === 'paid' ? 'pending' : 'paid' as 'paid' | 'pending' } : e
      );
      saveToStorage('expenses', expenses);
      return { expenses };
    });
  },

  addCard: (card) => {
    const newCard: CreditCard = { ...card, id: uuidv4(), createdAt: new Date().toISOString() };
    set(state => {
      const cards = [...state.cards, newCard];
      saveToStorage('cards', cards);
      return { cards };
    });
  },

  updateCard: (id, card) => {
    set(state => {
      const cards = state.cards.map(c => c.id === id ? { ...c, ...card } : c);
      saveToStorage('cards', cards);
      return { cards };
    });
  },

  deleteCard: (id) => {
    set(state => {
      const cards = state.cards.filter(c => c.id !== id);
      saveToStorage('cards', cards);
      return { cards };
    });
  },

  addGoal: (goal) => {
    const newGoal: FinancialGoal = { ...goal, id: uuidv4(), createdAt: new Date().toISOString() };
    set(state => {
      const goals = [...state.goals, newGoal];
      saveToStorage('goals', goals);
      return { goals };
    });
  },

  updateGoal: (id, goal) => {
    set(state => {
      const goals = state.goals.map(g => g.id === id ? { ...g, ...goal } : g);
      saveToStorage('goals', goals);
      return { goals };
    });
  },

  deleteGoal: (id) => {
    set(state => {
      const goals = state.goals.filter(g => g.id !== id);
      saveToStorage('goals', goals);
      return { goals };
    });
  },

  contributeToGoal: (id, amount) => {
    set(state => {
      const goals = state.goals.map(g => g.id === id ? { ...g, currentValue: Math.min(g.currentValue + amount, g.targetValue) } : g);
      saveToStorage('goals', goals);
      return { goals };
    });
  },
}));
